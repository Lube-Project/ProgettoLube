import React from 'react';
import '../css/App.css';

function Contact() {
  return (
    <div className="App">
      <h1>CONTACT</h1>
    </div>
  );
}

export default Contact;
