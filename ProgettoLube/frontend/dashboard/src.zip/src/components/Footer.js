import React from 'react';
import '../css/App.css';
import '../css/Footer.css';



function Footer() {
  return (
    <div className="Footer">
        <h5>Copyright - 2020 Romans & Teo & Cippy & Victor</h5>
    </div>
  );
}

export default Footer;
